﻿#include <GLFW\glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>

using namespace std;

const float DEG2RAD = 3.14159 / 180;

// Limit number of bricks in the scene
const int MAX_NUM_BRICKS = 15;

void processInput(GLFWwindow* window);

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

class Brick;
class Circle;

// Vectors for holding circles and bricks
vector<Circle> world;
vector<Brick> bricks;

// Track the number of bricks in the scene
int numberOfBricks;

class Brick
{
public:
	float red, green, blue;
	float x, y, width;
	int hitPoints;
	BRICKTYPE brick_type;
	ONOFF onoff;

	Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb, int hp)
	{
		brick_type = bt; x = xx; y = yy, width = ww; red = rr, green = gg, blue = bb, hitPoints = hp;
		onoff = ON;
	};

	void drawBrick()
	{
		if (onoff == ON)
		{
			double halfside = width / 2;

			glColor3d(red, green, blue);
			glBegin(GL_POLYGON);

			glVertex2d(x + halfside, y + halfside);
			glVertex2d(x + halfside, y - halfside);
			glVertex2d(x - halfside, y - halfside);
			glVertex2d(x - halfside, y + halfside);

			glEnd();
		}
	}
};


class Circle
{
public:
	float red, green, blue;
	float radius;
	float x;
	float y;
	float speed = 0.03;
	int direction; // 1=up 2=right 3=down 4=left 5 = up right   6 = up left  7 = down right  8= down left

	float randomCoordinate()
	{
		float randomCoord = (rand() % 10) / 10.0;
		if (rand() % 2 == 0) {
			randomCoord *= -1.0;
		}
		return randomCoord;
	}

	Circle(double xx, double yy, double rr, int dir, float rad, float r, float g, float b)
	{
		x = xx;
		y = yy;
		radius = rr;
		red = r;
		green = g;
		blue = b;
		radius = rad;
		direction = dir;
	}

	void CheckCollision(Brick* brk)
	{
		if (brk->brick_type == REFLECTIVE)
		{
			if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width))
			{
				direction = GetRandomDirection();
				x = x + 0.03;
				y = y + 0.04;

				// Each collision produces a new, smaller brick until max number of bricks is reached
				if (numberOfBricks < MAX_NUM_BRICKS) {
					Brick brick(DESTRUCTABLE, randomCoordinate(), randomCoordinate(), 0.1, 0.89, 0.89, 0.88, 1);
					bricks.push_back(brick);
					numberOfBricks++;
				}
			}
		}
		else if (brk->brick_type == DESTRUCTABLE)
		{
			if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width 
				&& y <= brk->y + brk->width) && brk->onoff == ON)
			{
				// Reduce hit points until one remains
				if (brk->hitPoints > 1) { 
					brk->hitPoints--;
					return;
				}

				// If break is turned off, reduce the count of bricks in the scene
				numberOfBricks--;         
				brk->onoff = OFF;		  
			}
		}
	}

	// If circles collide, both circles assigned new random direction
	void CheckCircleCollision(Circle* circle)
	{
		if ((x > circle->x - circle->radius && x <= circle->x + circle->radius) && (y > circle->y - circle->radius && y <= circle->y + circle->radius))
		{
			direction = GetRandomDirection();
			circle->direction = GetRandomDirection();
		}
	}

	int GetRandomDirection()
	{
		return (rand() % 8) + 1;
	}

	void MoveOneStep()
	{
		if (direction == 1 || direction == 5 || direction == 6)  // up
		{
			if (y > -1 + radius)
			{
				y -= speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		if (direction == 2 || direction == 5 || direction == 7)  // right
		{
			if (x < 1 - radius)
			{
				x += speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		if (direction == 3 || direction == 7 || direction == 8)  // down
		{
			if (y < 1 - radius) {
				y += speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		if (direction == 4 || direction == 6 || direction == 8)  // left
		{
			if (x > -1 + radius) {
				x -= speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		// Circles gradually speed up until going very fast, then change to very slow - Matrix style
		if (speed < 0.1) {
			speed += 0.0001;
		}
		else {
			speed = 0.01;
		}
	}

	void DrawCircle()
	{
		glColor3f(red, green, blue);
		glBegin(GL_POLYGON);
		for (int i = 0; i < 360; i++) {
			float degInRad = i * DEG2RAD;
			glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
		}
		glEnd();
	}
};


int main(void) {
	srand(time(NULL));

	if (!glfwInit()) {
		std::exit(EXIT_FAILURE);
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	GLFWwindow* window = glfwCreateWindow(480, 480, "David France Module 8", NULL, NULL);
	if (!window) {
		glfwTerminate();
		std::exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);

	Brick brick(DESTRUCTABLE, 0.5, -0.33, 0.3, 0.52, 0.43, 0.22, 100);
	Brick brick2(DESTRUCTABLE, -0.5, 0.33, 0.25, 0.40, 0.44, 0.18, 100);
	Brick brick3(REFLECTIVE, -0.5, -0.33, 0.2, 0.49, 0.60, 0.66, 1);
	Brick brick4(REFLECTIVE, 0, 0, 0.4, 0.89, 0.89, 0.88, 1);

	// Bricks are now kept in vector 
	bricks.push_back(brick);
	bricks.push_back(brick2);
	bricks.push_back(brick3);
	bricks.push_back(brick4);
	numberOfBricks = bricks.size();

	while (!glfwWindowShouldClose(window)) {
		//Setup View
		float ratio;
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		ratio = width / (float)height;
		glViewport(0, 0, width, height);
		glClear(GL_COLOR_BUFFER_BIT);

		processInput(window);

		//Movement
		for (int i = 0; i < world.size(); i++)
		{
			for (int j = 0; j < bricks.size(); j++)		// Handle collision with bricks for each circle
			{
				world[i].CheckCollision(&bricks[j]);
			}
			for (int k = i + 1; k < world.size(); k++)  // Handle circle collisions, only check each pair once
			{
				world[i].CheckCircleCollision(&world[k]);
			}
			world[i].MoveOneStep();
			world[i].DrawCircle();

		}

		for (int i = 0; i < bricks.size(); i++)
		{
			bricks[i].drawBrick();
		}

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate;
	return 0;
}


void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
	{
		double r, g, b;
		r = rand() / 10000;
		g = rand() / 10000;
		b = rand() / 10000;
		Circle B(0, 0, 02, 2, 0.05, r, g, b);
		world.push_back(B);
	}
}